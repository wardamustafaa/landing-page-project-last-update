/**
 * 
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 * 
 * Dependencies: None
 * 
 * JS Version: ES2015/ES6
 * 
 * JS Standard: ESlint
 * 
*/

/**
 * Define Global Variables
 * 
*/
//navigation global variable
const navigation = document.getElementById('navbar__list');
//sections global variable
let sections = document.querySelectorAll('section');




/**
 * End Global Variables
 * Start Helper Functions
 * 
*/



/**
 * End Helper Functions
 * Begin Main Functions
 * 
*/

// build the nav
const navBuilder = () => {
    let navUI = '' ;
    //looping over all sections
    sections.forEach(section =>{
        const sectionID = section.id;
        const sectionDataNav = section.dataset.nav;
        navUI += `<li><a  href="#${sectionID}">${sectionDataNav}</a></li>`;
    });
    //appent all elements to the navigation
    navigation.innerHTML = navUI;
};
navBuilder();
// Add class 'active' to section when near top of viewport
// get the data nav from the section
function get_active_link(active_section) {
let section_nav = active_section.getAttribute('data-nav');
//get all links
let anchors = document.querySelectorAll('a');
//loop on links
anchors.forEach((anchor) =>{
    if(anchor.textContent == section_nav){
        anchors.forEach( (anchor) => {  
            anchor.classList.remove('your-active-class'); 
        });
        //add active class to active link
        anchor.classList.add('your-active-class');
    };
});
};
// getting the largest value that's less or equal to the number
const offset = (section) =>{
    return Math.floor(section.getBoundingClientRect().top);
};
//remove the active class
const removeActive = (section) => {
    section.classList.remove('your-active-class');
};
//add the active class
const addActive = (conditional, section) => {
    if (conditional){
        section.classList.add('your-active-class');
        get_active_link(section);
    };
};
//implementing the actual fuction
const sectionActivation = () => {
    let links = document.querySelectorAll('a');
    sections.forEach(section => {
        const elementOffset = offset(section);
        inviewport = () => elementOffset < 150 && elementOffset >= -150;
        removeActive(section);
        addActive(inviewport(), section);
    });
};
window.addEventListener('scroll', sectionActivation);
 // Scroll to anchor using scrollIntoView event
const links = document.querySelectorAll(".page__header ul a");
 
for (const link of links) {
  link.addEventListener("click", clickHandler);
}
 
function clickHandler(e) {
  e.preventDefault();
  const href = this.getAttribute("href");
 
  document.querySelector(href).scrollIntoView({
    behavior: "smooth"
  });
}
/**
 * End Main Functions
 * Begin Events
 * 
*/



